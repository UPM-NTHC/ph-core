# transaction-example - Draft PH Core Implementation Guide v0.2.1

## Example Bundle: transaction-example

### Primary-care follow-up resource index

The resources below are inline members of this Bundle. Their FSH definitions are co-located with the Bundle and retain their PH Core `InstanceOf` profiles. Their IDs identify entries within the Bundle; they are not separately published example resources.

| | |
| :--- | :--- |
| `Task/task-single-example` | A laboratory task for Juan Dela Cruz requested by Dr. Maria Clara Santos. The task is to collect a blood sample for a ordered fasting blood glucose test. |
| `ServiceRequest/servicerequest-hba1c-example` | Completed HbA1c order for Juan Dela Cruz's diabetes follow-up on 15 March 2025. |
| `Observation/observation-based-on-service-example` | Hemoglobin A1c lab result based on a service request for diabetes monitoring. |
| `Observation/observation-bp-followup-example` | Blood pressure recorded during Juan Dela Cruz's outpatient follow-up on 15 March 2025. |
| `MedicationRequest/medicationrequest-single-example` | Dr. Maria Clara Santos renews Twinact (Telmisartan + Amlodipine) for Juan Dela Cruz to treat hypertension. |
| `MedicationDispense/medicationdispense-single-example` | Pharmacy dispenses Twinact (Telmisartan + Amlodipine) to Juan Dela Cruz based on Dr. Santos prescription. |
| `MedicationStatement/medicationstatement-single-example` | Patient Juan Dela Cruz reports taking Twinact (Telmisartan + Amlodipine) for hypertension. |
| `MedicationAdministration/medicationadministration-single-example` | Juan Dela Cruz takes Twinact (Telmisartan + Amlodipine) tablet as prescribed. |

Shared core examples included by this Bundle, such as the facility and credential issuer, remain separately published so other scenarios can reuse them. See the [scenario narrative](examples.md) and this Bundle's JSON view for the complete linked data.



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "transaction-example",
  "type" : "transaction",
  "entry" : [{
    "fullUrl" : "https://example.org/fhir/Patient/patient-single-example",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "patient-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_patient-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient patient-single-example</b></p><a name=\"patient-single-example\"> </a><a name=\"hcpatient-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-patient.html\">PH Core Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">123 Mabini Street Ermita City of Manila 1000 PH </td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Draft representation of a person-reported race classification. The inherited terminology choice requires Philippine use-case appraisal.\"><a href=\"StructureDefinition-race.html\">Race</a></td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-Race 2036-2}\">Filipino</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The nationality of the patient.\">Patient Nationality:</td><td colspan=\"3\"><ul><li>code: <span title=\"Codes:{urn:iso:std:iso:3166 PH}\">Philippines</span></li><li>period: 2020-01-01 --&gt; 2023-01-01</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Indigenous / ethnic group that the patient belongs to.\"><a href=\"StructureDefinition-indigenous-status.html\">Indigenous status</a></td><td colspan=\"3\"><span title=\"Codes:{https://fhir.doh.gov.ph/phcore/CodeSystem/indigenous-status-cs Aetas}\">Aetas</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Highest educational attainment of the patient.\"><a href=\"StructureDefinition-educational-attainment.html\">Educational Attainment</a></td><td colspan=\"3\"><span title=\"Codes:{https://psa.gov.ph/classification/psced/level C201303}\">College Graduate</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Mother's maiden (unmarried) name, commonly collected to help verify patient identity.\"><a href=\"http://hl7.org/fhir/extensions/5.3.0/StructureDefinition-patient-mothersMaidenName.html\">Patient Mother's Maiden Name</a></td><td colspan=\"3\">Maria Cruz Santos</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient's occupation.\">Occupation:</td><td colspan=\"3\"><ul><li>occupationClassification: <span title=\"Codes:{https://psa.gov.ph/classification/psoc/unit 111102}\">Hospital Administrator</span></li><li>occupationLength: 2020-01-01 --&gt; (ongoing)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The patient's professed religious affiliations.\"><a href=\"http://hl7.org/fhir/extensions/5.3.0/StructureDefinition-patient-religion.html\">Patient Religion</a></td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ReligiousAffiliation 1007}\">Atheism</span></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "urn:iso:std:iso:3166",
              "code" : "PH",
              "display" : "Philippines"
            }]
          }
        },
        {
          "url" : "period",
          "valuePeriod" : {
            "start" : "2020-01-01",
            "end" : "2023-01-01"
          }
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-nationality"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-mothersMaidenName",
        "valueString" : "Maria Cruz Santos"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/patient-religion",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ReligiousAffiliation",
            "code" : "1007",
            "display" : "Atheism"
          }]
        }
      },
      {
        "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/indigenous-status",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://fhir.doh.gov.ph/phcore/CodeSystem/indigenous-status-cs",
            "code" : "Aetas",
            "display" : "Aetas"
          }]
        }
      },
      {
        "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/race",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-Race",
            "code" : "2036-2",
            "display" : "Filipino"
          }]
        }
      },
      {
        "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/educational-attainment",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://psa.gov.ph/classification/psced/level",
            "code" : "C201303",
            "display" : "College Graduate"
          }]
        }
      },
      {
        "extension" : [{
          "url" : "occupationClassification",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "https://psa.gov.ph/classification/psoc/unit",
              "code" : "111102",
              "display" : "Hospital Administrator"
            }]
          }
        },
        {
          "url" : "occupationLength",
          "valuePeriod" : {
            "start" : "2020-01-01"
          }
        }],
        "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/occupation"
      }],
      "identifier" : [{
        "system" : "http://philhealth.gov.ph/fhir/Identifier/philhealth-id",
        "value" : "63-584789845-5"
      }],
      "active" : true,
      "name" : [{
        "family" : "Dela Cruz",
        "given" : ["Juan", "Dela Fuente"]
      }],
      "gender" : "male",
      "birthDate" : "1980-01-01",
      "address" : [{
        "extension" : [{
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/city-municipality",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1380600000",
            "display" : "City of Manila"
          }
        },
        {
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/region",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "0402100000",
            "display" : "Cavite"
          }
        }],
        "line" : ["123 Mabini Street", "Ermita"],
        "city" : "City of Manila",
        "district" : "NCR",
        "postalCode" : "1000",
        "country" : "PH"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Organization/organization-pgh-example",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "organization-pgh-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_organization-pgh-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization organization-pgh-example</b></p><a name=\"organization-pgh-example\"> </a><a name=\"hcorganization-pgh-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-organization.html\">PH Core Organization</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The kind(s) of organization that this is\">Type:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type prov}\">Healthcare Provider</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li><code>http://nhdr.gov.ph/fhir/Identifier/philhealthaccreditationnumber</code>/PAN-2024-56789</li><li><code>http://nhdr.gov.ph/fhir/Identifier/philhealthemployernumber</code>/PEN-987654321</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the organization\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+63-2-8651-7800\">+63-2-8651-7800</a></li><li><a href=\"mailto:contact@pgh.gov.ph\">contact@pgh.gov.ph</a></li><li>Taft Avenue Manila 1000 PH (work)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the organization\">Contact Detail</td><td colspan=\"3\"><ul><li>Hospital Administrator</li><li><a href=\"tel:+63-2-8651-7801\">+63-2-8651-7801</a></li><li>Taft Avenue Manila 1000 PH (work)</li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "https://nhfr.doh.gov.ph/",
        "value" : "1234567890"
      },
      {
        "system" : "http://nhdr.gov.ph/fhir/Identifier/philhealthaccreditationnumber",
        "value" : "PAN-2024-56789"
      },
      {
        "system" : "http://nhdr.gov.ph/fhir/Identifier/philhealthemployernumber",
        "value" : "PEN-987654321"
      }],
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "prov",
          "display" : "Healthcare Provider"
        }]
      }],
      "name" : "Philippine General Hospital",
      "telecom" : [{
        "system" : "phone",
        "value" : "+63-2-8651-7800",
        "use" : "work"
      },
      {
        "system" : "email",
        "value" : "contact@pgh.gov.ph",
        "use" : "work"
      }],
      "address" : [{
        "extension" : [{
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/region",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1300000000"
          }
        },
        {
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/city-municipality",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1380600000"
          }
        }],
        "use" : "work",
        "type" : "both",
        "line" : ["Taft Avenue"],
        "city" : "Manila",
        "district" : "NCR",
        "postalCode" : "1000",
        "country" : "PH"
      }],
      "contact" : [{
        "name" : {
          "text" : "Hospital Administrator"
        },
        "telecom" : [{
          "system" : "phone",
          "value" : "+63-2-8651-7801"
        }],
        "address" : {
          "extension" : [{
            "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/region",
            "valueCoding" : {
              "system" : "https://psa.gov.ph/classification/psgc",
              "code" : "1300000000"
            }
          },
          {
            "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/city-municipality",
            "valueCoding" : {
              "system" : "https://psa.gov.ph/classification/psgc",
              "code" : "1380600000"
            }
          }],
          "use" : "work",
          "line" : ["Taft Avenue"],
          "city" : "Manila",
          "postalCode" : "1000",
          "country" : "PH"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Organization/organization-prc-example",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "organization-prc-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-organization"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_organization-prc-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization organization-prc-example</b></p><a name=\"organization-prc-example\"> </a><a name=\"hcorganization-prc-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-organization.html\">PH Core Organization</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Professional Regulation Commission (illustrative) (Government)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The kind(s) of organization that this is\">Type:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type govt}\">Government</span></td></tr></table></div>"
      },
      "active" : true,
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "govt",
          "display" : "Government"
        }]
      }],
      "name" : "Professional Regulation Commission (illustrative)"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Practitioner/practitioner-single-example",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "practitioner-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-practitioner"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_practitioner-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner practitioner-single-example</b></p><a name=\"practitioner-single-example\"> </a><a name=\"hcpractitioner-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-practitioner.html\">PH Core Practitioner</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Maria Clara Santos (official)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Administrative gender\">Gender:</td><td>Female</td><td style=\"background-color: #f3f5da\" title=\"Date of birth\">Date of Birth:</td><td>1985-05-15</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Practitioner\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+63-912-345-6789\">+63-912-345-6789</a></li><li><a href=\"mailto:maria.santos@example.ph\">maria.santos@example.ph</a></li><li>1234 Mabini Street 1000 PH (home)</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Certification, licensure, or training pertaining to the provision of care\">Qualification:</td><td colspan=\"3\"><span title=\"Codes:{https://fhir.doh.gov.ph/phcore/CodeSystem/prc 2200}\">Physician</span><ul><li>Identifier: <code>https://www.prc.gov.ph</code>/0123456</li><li>Valid Period: 2010-07-15 --&gt; (ongoing)</li><li>Issued By: <a href=\"Organization-organization-prc-example.html\">Professional Regulation Commission (illustrative) (Government)</a></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Languages spoken\">Languages:</td><td colspan=\"3\"><ul><li><span title=\"Codes:\">Filipino</span></li><li><span title=\"Codes:{urn:ietf:bcp:47 en}\">English</span></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The pronouns to use when referring to an individual in verbal or written communication.\">Individual Pronouns:</td><td colspan=\"3\"><ul><li>value: <span title=\"Codes:{http://loinc.org LA29519-8}\">she/her/her/hers/herself</span></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Recorded sex or gender (RSG) information includes the various sex and gender concepts that are often used in existing systems but are known NOT to represent a gender identity, sex parameter for clinical use, or attributes related to sexuality, such as sexual orientation, sexual activity, or sexual attraction. Examples of recorded sex or gender concepts include administrative gender, administrative sex, and sex assigned at birth.  When exchanging this concept, refer to the guidance in the [Gender Harmony Implementation Guide](http://hl7.org/xprod/ig/uv/gender-harmony/).\">Person Recorded Sex Or Gender:</td><td colspan=\"3\"><ul><li>value: <span title=\"Codes:{http://snomed.info/sct 248152002}\">Female (finding)</span></li><li>type: <span title=\"Codes:{http://loinc.org 76689-9}\">Sex Assigned at Birth</span></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"An individual's personal sense of being a man, woman, boy, girl, nonbinary, or something else. This represents an individual’s identity, ascertained by asking them what that identity is. \n In the case where the gender identity is communicated by a third party, for example, if a spouse indicates the gender identity of their partner on an intake form, a Provenance resource can be used with a Provenance.target referring to the Patient, with a targetElement extension identifying the gender identity extension as the target element within the Patient resource.  When exchanging this concept, refer to the guidance in the [Gender Harmony Implementation Guide](http://hl7.org/xprod/ig/uv/gender-harmony/).\">Individual Gender Identity:</td><td colspan=\"3\"><ul><li>value: <span title=\"Codes:{http://snomed.info/sct 446141000124107}\">Identifies as female gender</span></li></ul></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "value",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "248152002",
              "display" : "Female (finding)"
            }]
          }
        },
        {
          "url" : "type",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "76689-9",
              "display" : "Sex Assigned at Birth"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/individual-recordedSexOrGender"
      },
      {
        "extension" : [{
          "url" : "value",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://snomed.info/sct",
              "code" : "446141000124107",
              "display" : "Identifies as female gender"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/individual-genderIdentity"
      },
      {
        "extension" : [{
          "url" : "value",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "LA29519-8",
              "display" : "she/her/her/hers/herself"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/individual-pronouns"
      }],
      "name" : [{
        "use" : "official",
        "family" : "Santos",
        "given" : ["Maria", "Clara"],
        "suffix" : ["MD"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+63-912-345-6789",
        "use" : "mobile"
      },
      {
        "system" : "email",
        "value" : "maria.santos@example.ph",
        "use" : "work"
      }],
      "address" : [{
        "extension" : [{
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/city-municipality",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1380600000",
            "display" : "City of Manila"
          }
        },
        {
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/region",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1300000000",
            "display" : "National Capital Region (NCR)"
          }
        }],
        "use" : "home",
        "line" : ["1234 Mabini Street"],
        "postalCode" : "1000",
        "country" : "PH"
      }],
      "gender" : "female",
      "birthDate" : "1985-05-15",
      "qualification" : [{
        "identifier" : [{
          "system" : "https://www.prc.gov.ph",
          "value" : "0123456"
        }],
        "code" : {
          "coding" : [{
            "system" : "https://fhir.doh.gov.ph/phcore/CodeSystem/prc",
            "code" : "2200",
            "display" : "Physician"
          }]
        },
        "period" : {
          "start" : "2010-07-15"
        },
        "issuer" : {
          "reference" : "Organization/organization-prc-example"
        }
      }],
      "communication" : [{
        "text" : "Filipino"
      },
      {
        "coding" : [{
          "system" : "urn:ietf:bcp:47",
          "code" : "en",
          "display" : "English"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/PractitionerRole/practitionerrole-single-example",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "practitionerrole-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-practitionerrole"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_practitionerrole-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole practitionerrole-single-example</b></p><a name=\"practitionerrole-single-example\"> </a><a name=\"hcpractitionerrole-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-practitionerrole.html\">PH Core PractitionerRole</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Maria Clara Santos (official): Physician at Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890) (http://doh.gov.ph/fhir/Identifier/practitioner-role-id#PR-OPD-001)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The practitioner who is able to provide the services in this role\">Practitioner:</td><td colspan=\"3\"><a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The organization where the practitioner performs the roles\">Organization:</td><td colspan=\"3\"><a href=\"Organization-organization-pgh-example.html\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</a></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Roles which this practitioner is authorized to perform for the organization\">Role:</td><td colspan=\"3\"><span title=\"Codes:{https://fhir.doh.gov.ph/phcore/CodeSystem/prc 2200}\">Physician</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The specialties of the practitioner in this role\">Specialty:</td><td colspan=\"3\"><span title=\"Codes:{http://snomed.info/sct 394802001}\">General medicine</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The locations at which the practitioner provides care\">Location:</td><td colspan=\"3\"><a href=\"Location-location-single-example.html\">Philippine General Hospital (Hospital)</a></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the practitioner in this role\">Contact Detail</td><td colspan=\"3\"><ul><li><a href=\"tel:+63-2-8651-7800\">+63-2-8651-7800</a></li><li><a href=\"mailto:maria.santos@doh.gov.ph\">maria.santos@doh.gov.ph</a></li></ul></td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://doh.gov.ph/fhir/Identifier/practitioner-role-id",
        "value" : "PR-OPD-001"
      }],
      "active" : true,
      "practitioner" : {
        "reference" : "Practitioner/practitioner-single-example"
      },
      "organization" : {
        "reference" : "Organization/organization-pgh-example"
      },
      "code" : [{
        "coding" : [{
          "system" : "https://fhir.doh.gov.ph/phcore/CodeSystem/prc",
          "code" : "2200",
          "display" : "Physician"
        }]
      }],
      "specialty" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "394802001",
          "display" : "General medicine"
        }]
      }],
      "location" : [{
        "reference" : "Location/location-single-example"
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "+63-2-8651-7800"
      },
      {
        "system" : "email",
        "value" : "maria.santos@doh.gov.ph"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "PractitionerRole"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Location/location-single-example",
    "resource" : {
      "resourceType" : "Location",
      "id" : "location-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-location"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_location-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location location-single-example</b></p><a name=\"location-single-example\"> </a><a name=\"hclocation-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-location.html\">PH Core Location</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Philippine General Hospital (Hospital)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"The status of the location\">Status:</td><td>Active</td><td style=\"background-color: #f3f5da\" title=\"The physical form of the location (e.g. building, room, vehicle, road)\">Form:</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/location-physical-type bu}\">Building</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The type of function performed at the location\">Type:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode HOSP}\">Hospital</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Physical location\">Address:</td><td colspan=\"3\">Taft Avenue 1000 PH (work)</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The latitude and longitude of the location (WGS84)\">Position:</td><td colspan=\"3\">14.5764, 120.9856</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"The organization responsible for the provisioning and upkeep of the location\">Managed By:</td><td colspan=\"3\"><a href=\"Organization-organization-pgh-example.html\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</a></td></tr></table></div>"
      },
      "status" : "active",
      "name" : "Philippine General Hospital",
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "HOSP",
          "display" : "Hospital"
        }],
        "text" : "Hospital"
      }],
      "address" : {
        "extension" : [{
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/region",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1300000000",
            "display" : "National Capital Region (NCR)"
          }
        },
        {
          "url" : "https://fhir.doh.gov.ph/phcore/StructureDefinition/city-municipality",
          "valueCoding" : {
            "system" : "https://psa.gov.ph/classification/psgc",
            "code" : "1380600000",
            "display" : "City of Manila"
          }
        }],
        "use" : "work",
        "line" : ["Taft Avenue"],
        "postalCode" : "1000",
        "country" : "PH"
      },
      "physicalType" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
          "code" : "bu",
          "display" : "Building"
        }],
        "text" : "Building"
      },
      "position" : {
        "longitude" : 120.9856,
        "latitude" : 14.5764
      },
      "managingOrganization" : {
        "reference" : "Organization/organization-pgh-example"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Location"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Condition/condition-single-example",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "condition-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-condition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_condition-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition condition-single-example</b></p><a name=\"condition-single-example\"> </a><a name=\"hccondition-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-condition.html\">PH Core Condition</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-category problem-list-item}\">Problem List Item</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 44054006}\">Type 2 Diabetes Mellitus</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>onset</b>: 2020-03-15</p><p><b>recordedDate</b>: 2025-03-15 09:00:00+0800</p><p><b>note</b>: </p><blockquote><div><p>Patient advised on diet and exercise management.</p>\n</div></blockquote></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
          "code" : "active",
          "display" : "Active"
        }]
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
          "code" : "confirmed",
          "display" : "Confirmed"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/condition-category",
          "code" : "problem-list-item",
          "display" : "Problem List Item"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "44054006",
          "display" : "Diabetes mellitus type 2"
        }],
        "text" : "Type 2 Diabetes Mellitus"
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "onsetDateTime" : "2020-03-15",
      "recordedDate" : "2025-03-15T09:00:00+08:00",
      "note" : [{
        "text" : "Patient advised on diet and exercise management."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Condition"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Encounter/encounter-single-example",
    "resource" : {
      "resourceType" : "Encounter",
      "id" : "encounter-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-encounter"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_encounter-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter encounter-single-example</b></p><a name=\"encounter-single-example\"> </a><a name=\"hcencounter-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-encounter.html\">PH Core Encounter</a></p></div><p><b>identifier</b>: <code>http://example.org/encounter-id</code>/ENC-12345</p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode: AMB</a> (ambulatory)</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ActCode AMB}\">ambulatory</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><h3>Participants</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Individual</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ParticipationType ATND}\">attender</span></td><td><a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></td></tr></table><p><b>period</b>: 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</p><p><b>reasonReference</b>: <a href=\"Condition-condition-single-example.html\">Condition Type 2 Diabetes Mellitus</a></p><h3>Diagnoses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Condition</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Condition-condition-single-example.html\">Condition Type 2 Diabetes Mellitus</a></td></tr></table><p><b>serviceProvider</b>: <a href=\"Organization-organization-pgh-example.html\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</a></p></div>"
      },
      "identifier" : [{
        "system" : "http://example.org/encounter-id",
        "value" : "ENC-12345"
      }],
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB",
        "display" : "ambulatory"
      },
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "AMB",
          "display" : "ambulatory"
        }]
      }],
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "participant" : [{
        "type" : [{
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
            "code" : "ATND",
            "display" : "attender"
          }]
        }],
        "individual" : {
          "reference" : "Practitioner/practitioner-single-example"
        }
      }],
      "period" : {
        "start" : "2025-03-15T09:00:00+08:00",
        "end" : "2025-03-15T11:30:00+08:00"
      },
      "reasonReference" : [{
        "reference" : "Condition/condition-single-example"
      }],
      "diagnosis" : [{
        "condition" : {
          "reference" : "Condition/condition-single-example"
        }
      }],
      "serviceProvider" : {
        "reference" : "Organization/organization-pgh-example"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Encounter"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/ServiceRequest/servicerequest-single-example",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "servicerequest-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-serviceRequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_servicerequest-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest servicerequest-single-example</b></p><a name=\"servicerequest-single-example\"> </a><a name=\"hcservicerequest-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-serviceRequest.html\">PH Core ServiceRequest</a></p></div><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108252007}\">Laboratory procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 33747003}\">Fasting blood glucose test</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>occurrence</b>: 2025-03-15 10:00:00+0800</p><p><b>authoredOn</b>: 2025-03-15 09:30:00+0800</p><p><b>requester</b>: <a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></p><p><b>supportingInfo</b>: <a href=\"Condition-condition-single-example.html\">Condition Type 2 Diabetes Mellitus</a></p></div>"
      },
      "status" : "completed",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108252007",
          "display" : "Laboratory procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "33747003",
          "display" : "Glucose measurement, blood"
        }],
        "text" : "Fasting blood glucose test"
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "occurrenceDateTime" : "2025-03-15T10:00:00+08:00",
      "authoredOn" : "2025-03-15T09:30:00+08:00",
      "requester" : {
        "reference" : "Practitioner/practitioner-single-example"
      },
      "supportingInfo" : [{
        "reference" : "Condition/condition-single-example"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/ServiceRequest/servicerequest-hba1c-example",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "servicerequest-hba1c-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-serviceRequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_servicerequest-hba1c-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest servicerequest-hba1c-example</b></p><a name=\"servicerequest-hba1c-example\"> </a><a name=\"hcservicerequest-hba1c-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-serviceRequest.html\">PH Core ServiceRequest</a></p></div><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108252007}\">Laboratory procedure</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 4548-4}\">Hemoglobin A1c/Hemoglobin.total in Blood</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>authoredOn</b>: 2025-03-15 09:30:00+0800</p><p><b>requester</b>: <a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></p><p><b>supportingInfo</b>: <a href=\"Condition-condition-single-example.html\">Condition Type 2 Diabetes Mellitus</a></p></div>"
      },
      "status" : "completed",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108252007",
          "display" : "Laboratory procedure"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "4548-4",
          "display" : "Hemoglobin A1c/Hemoglobin.total in Blood"
        }]
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "authoredOn" : "2025-03-15T09:30:00+08:00",
      "requester" : {
        "reference" : "Practitioner/practitioner-single-example"
      },
      "supportingInfo" : [{
        "reference" : "Condition/condition-single-example"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Task/task-single-example",
    "resource" : {
      "resourceType" : "Task",
      "id" : "task-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-task"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_task-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Task task-single-example</b></p><a name=\"task-single-example\"> </a><a name=\"hctask-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-task.html\">PH Core Task</a></p></div><p><b>status</b>: Completed</p><p><b>intent</b>: order</p><p><b>priority</b>: Routine</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 82078001}\">Blood sample collection</span></p><p><b>description</b>: Collect blood sample for the ordered fasting blood glucose test</p><p><b>focus</b>: <a href=\"ServiceRequest-servicerequest-single-example.html\">ServiceRequest Fasting blood glucose test</a></p><p><b>for</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>executionPeriod</b>: 2025-03-15 09:40:00+0800 --&gt; 2025-03-15 10:15:00+0800</p><p><b>authoredOn</b>: 2025-03-15 09:35:00+0800</p><p><b>lastModified</b>: 2025-03-15 10:15:00+0800</p><p><b>requester</b>: <a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></p><p><b>owner</b>: <a href=\"Organization-organization-pgh-example.html\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</a></p><p><b>note</b>: By Practitioner/practitioner-single-example @2025-03-15 10:15:00+0800</p><blockquote><div><p>Fasting status was checked before specimen collection.</p>\n</div></blockquote></div>"
      },
      "status" : "completed",
      "intent" : "order",
      "priority" : "routine",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "82078001",
          "display" : "Collection of blood specimen for laboratory"
        }],
        "text" : "Blood sample collection"
      },
      "description" : "Collect blood sample for the ordered fasting blood glucose test",
      "focus" : {
        "reference" : "ServiceRequest/servicerequest-single-example"
      },
      "for" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "executionPeriod" : {
        "start" : "2025-03-15T09:40:00+08:00",
        "end" : "2025-03-15T10:15:00+08:00"
      },
      "authoredOn" : "2025-03-15T09:35:00+08:00",
      "lastModified" : "2025-03-15T10:15:00+08:00",
      "requester" : {
        "reference" : "Practitioner/practitioner-single-example"
      },
      "owner" : {
        "reference" : "Organization/organization-pgh-example"
      },
      "note" : [{
        "authorReference" : {
          "reference" : "Practitioner/practitioner-single-example"
        },
        "time" : "2025-03-15T10:15:00+08:00",
        "text" : "Fasting status was checked before specimen collection."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Task"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Observation/observation-bp-followup-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-bp-followup-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-observation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-bp-followup-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-bp-followup-example</b></p><a name=\"observation-bp-followup-example\"> </a><a name=\"hcobservation-bp-followup-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-observation.html\">PH Core Observation</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 85354-9}\">Blood pressure panel with all children optional</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>effective</b>: 2025-03-15 09:15:00+0800</p><p><b>performer</b>: <a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8480-6}\">Systolic blood pressure</span></p><p><b>value</b>: 120 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8462-4}\">Diastolic blood pressure</span></p><p><b>value</b>: 80 mmHg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemm[Hg] = 'mm[Hg]')</span></p></blockquote></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85354-9",
          "display" : "Blood pressure panel with all children optional"
        }]
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "effectiveDateTime" : "2025-03-15T09:15:00+08:00",
      "performer" : [{
        "reference" : "Practitioner/practitioner-single-example"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8480-6",
            "display" : "Systolic blood pressure"
          }]
        },
        "valueQuantity" : {
          "value" : 120,
          "unit" : "mmHg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "8462-4",
            "display" : "Diastolic blood pressure"
          }]
        },
        "valueQuantity" : {
          "value" : 80,
          "unit" : "mmHg",
          "system" : "http://unitsofmeasure.org",
          "code" : "mm[Hg]"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Observation/observation-vitals-encounter-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-vitals-encounter-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-observation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-vitals-encounter-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-vitals-encounter-example</b></p><a name=\"observation-vitals-encounter-example\"> </a><a name=\"hcobservation-vitals-encounter-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-observation.html\">PH Core Observation</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 8310-5}\">Body temperature</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>effective</b>: 2025-03-15 09:15:00+0800</p><p><b>performer</b>: <a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></p><p><b>value</b>: 37 degrees Celsius<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeCel = 'Cel')</span></p></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs",
          "display" : "Vital Signs"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "8310-5",
          "display" : "Body temperature"
        }]
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "effectiveDateTime" : "2025-03-15T09:15:00+08:00",
      "performer" : [{
        "reference" : "Practitioner/practitioner-single-example"
      }],
      "valueQuantity" : {
        "value" : 37,
        "unit" : "degrees Celsius",
        "system" : "http://unitsofmeasure.org",
        "code" : "Cel"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Observation/observation-glucose-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-glucose-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-observation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-glucose-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-glucose-example</b></p><a name=\"observation-glucose-example\"> </a><a name=\"hcobservation-glucose-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-observation.html\">PH Core Observation</a></p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-servicerequest-single-example.html\">ServiceRequest Fasting blood glucose test</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 1558-6}\">Fasting glucose [Mass/volume] in Serum or Plasma</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>effective</b>: 2025-03-15 10:30:00+0800</p><p><b>performer</b>: <a href=\"Organization-organization-pgh-example.html\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</a></p><p><b>value</b>: 95 mg/dL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></p><p><b>interpretation</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation N}\">Normal</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>70 mg/dL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></td><td>100 mg/dL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemg/dL = 'mg/dL')</span></td></tr></table></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/servicerequest-single-example"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "1558-6",
          "display" : "Fasting glucose [Mass/volume] in Serum or Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "effectiveDateTime" : "2025-03-15T10:30:00+08:00",
      "performer" : [{
        "reference" : "Organization/organization-pgh-example"
      }],
      "valueQuantity" : {
        "value" : 95,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "interpretation" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
          "code" : "N",
          "display" : "Normal"
        }]
      }],
      "referenceRange" : [{
        "low" : {
          "value" : 70,
          "unit" : "mg/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        },
        "high" : {
          "value" : 100,
          "unit" : "mg/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Observation/observation-based-on-service-example",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "observation-based-on-service-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-observation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_observation-based-on-service-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation observation-based-on-service-example</b></p><a name=\"observation-based-on-service-example\"> </a><a name=\"hcobservation-based-on-service-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-observation.html\">PH Core Observation</a></p></div><p><b>basedOn</b>: <a href=\"Bundle-transaction-example.html#ServiceRequest_servicerequest-hba1c-example\">ServiceRequest Hemoglobin A1c/Hemoglobin.total in Blood</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 4548-4}\">Hemoglobin A1c/Hemoglobin.total in Blood</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>effective</b>: 2025-03-15 10:30:00+0800</p><p><b>performer</b>: <a href=\"Organization-organization-pgh-example.html\">Philippine General Hospital (Healthcare Provider) (https://nhfr.doh.gov.ph/#1234567890)</a></p><p><b>value</b>: 6.2 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p><p><b>note</b>: </p><blockquote><div><p>Illustrative monitoring result; interpretation depends on the clinical context.</p>\n</div></blockquote></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/servicerequest-hba1c-example"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "4548-4",
          "display" : "Hemoglobin A1c/Hemoglobin.total in Blood"
        }]
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "effectiveDateTime" : "2025-03-15T10:30:00+08:00",
      "performer" : [{
        "reference" : "Organization/organization-pgh-example"
      }],
      "valueQuantity" : {
        "value" : 6.2,
        "unit" : "%",
        "system" : "http://unitsofmeasure.org",
        "code" : "%"
      },
      "note" : [{
        "text" : "Illustrative monitoring result; interpretation depends on the clinical context."
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Medication/medication-single-example",
    "resource" : {
      "resourceType" : "Medication",
      "id" : "medication-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-medication"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_medication-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Medication medication-single-example</b></p><a name=\"medication-single-example\"> </a><a name=\"hcmedication-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-medication.html\">PH Core Medication</a></p></div><p><b>code</b>: <span title=\"Codes:{https://verification.fda.gov.ph DRP-10144}\">Twinact 40mg/5mg tablet</span></p><p><b>form</b>: <span title=\"Codes:{http://snomed.info/sct 385055001}\">Tablet</span></p></div>"
      },
      "code" : {
        "coding" : [{
          "system" : "https://verification.fda.gov.ph",
          "code" : "DRP-10144",
          "display" : "Twinact"
        }],
        "text" : "Twinact 40mg/5mg tablet"
      },
      "form" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "385055001",
          "display" : "Tablet"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Medication"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/MedicationRequest/medicationrequest-single-example",
    "resource" : {
      "resourceType" : "MedicationRequest",
      "id" : "medicationrequest-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-medicationrequest"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationRequest_medicationrequest-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationRequest medicationrequest-single-example</b></p><a name=\"medicationrequest-single-example\"> </a><a name=\"hcmedicationrequest-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-medicationrequest.html\">PH Core Medication Request</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>priority</b>: Routine</p><p><b>medication</b>: <span title=\"Codes:{https://verification.fda.gov.ph DRP-10144}\">Twinact 40mg/5mg tablet</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>encounter</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>authoredOn</b>: 2025-03-15 09:00:00+0800</p><p><b>requester</b>: <a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 38341003}\">Hypertensive disorder</span></p><p><b>note</b>: </p><blockquote><div><p>Continue the prescribed once-daily antihypertensive medication</p>\n</div></blockquote><blockquote><p><b>dosageInstruction</b></p><p><b>sequence</b>: 1</p><p><b>text</b>: Take 1 tablet once daily</p><p><b>timing</b>: Once per 1 day</p><p><b>route</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration PO}\">Swallow, oral</span></p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 tablet<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td></tr></table></blockquote><h3>DispenseRequests</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>NumberOfRepeatsAllowed</b></td><td><b>Quantity</b></td></tr><tr><td style=\"display: none\">*</td><td>0</td><td>30 Tablet<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet')</span></td></tr></table></div>"
      },
      "status" : "active",
      "intent" : "order",
      "priority" : "routine",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "https://verification.fda.gov.ph",
          "code" : "DRP-10144",
          "display" : "Twinact"
        }],
        "text" : "Twinact 40mg/5mg tablet"
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "encounter" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "authoredOn" : "2025-03-15T09:00:00+08:00",
      "requester" : {
        "reference" : "Practitioner/practitioner-single-example"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "38341003",
          "display" : "Hypertensive disorder"
        }]
      }],
      "note" : [{
        "text" : "Continue the prescribed once-daily antihypertensive medication"
      }],
      "dosageInstruction" : [{
        "sequence" : 1,
        "text" : "Take 1 tablet once daily",
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration",
            "code" : "PO",
            "display" : "Swallow, oral"
          }]
        },
        "doseAndRate" : [{
          "doseQuantity" : {
            "value" : 1,
            "unit" : "tablet",
            "system" : "http://unitsofmeasure.org",
            "code" : "1"
          }
        }]
      }],
      "dispenseRequest" : {
        "numberOfRepeatsAllowed" : 0,
        "quantity" : {
          "value" : 30,
          "unit" : "Tablet",
          "system" : "http://snomed.info/sct",
          "code" : "732936001"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationRequest"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/MedicationDispense/medicationdispense-single-example",
    "resource" : {
      "resourceType" : "MedicationDispense",
      "id" : "medicationdispense-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-medicationdispense"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationDispense_medicationdispense-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationDispense medicationdispense-single-example</b></p><a name=\"medicationdispense-single-example\"> </a><a name=\"hcmedicationdispense-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-medicationdispense.html\">PH Core Medication Dispense</a></p></div><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{https://verification.fda.gov.ph DRP-10144}\">Twinact 40mg/5mg tablet</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>context</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Function</b></td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/medicationdispense-performer-function finalchecker}\">Final Checker</span></td><td><a href=\"Practitioner-practitioner-single-example.html\">Maria Clara Santos (official)</a></td></tr></table><p><b>authorizingPrescription</b>: <a href=\"Bundle-transaction-example.html#MedicationRequest_medicationrequest-single-example\">MedicationRequest: status = active; intent = order; priority = routine; medication[x] = Twinact 40mg/5mg tablet; authoredOn = 2025-03-15 09:00:00+0800; reasonCode = Hypertensive disorder; note = Continue the prescribed once-daily antihypertensive medication</a></p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 373784005}\">Dispensing medication</span></p><p><b>quantity</b>: 30 Tablet<span style=\"background: LightGoldenRodYellow\"> (Details: SNOMED CT  code732936001 = 'Tablet')</span></p><p><b>daysSupply</b>: 30 days<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  coded = 'd')</span></p><p><b>whenPrepared</b>: 2025-03-15 10:30:00+0800</p><p><b>whenHandedOver</b>: 2025-03-15 11:00:00+0800</p><h3>DosageInstructions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Text</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td>Take 1 tablet once daily</td></tr></table></div>"
      },
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "https://verification.fda.gov.ph",
          "code" : "DRP-10144",
          "display" : "Twinact"
        }],
        "text" : "Twinact 40mg/5mg tablet"
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "context" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "performer" : [{
        "function" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/medicationdispense-performer-function",
            "code" : "finalchecker",
            "display" : "Final Checker"
          }]
        },
        "actor" : {
          "reference" : "Practitioner/practitioner-single-example"
        }
      }],
      "authorizingPrescription" : [{
        "reference" : "MedicationRequest/medicationrequest-single-example"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "373784005",
          "display" : "Dispensing medication"
        }]
      },
      "quantity" : {
        "value" : 30,
        "unit" : "Tablet",
        "system" : "http://snomed.info/sct",
        "code" : "732936001"
      },
      "daysSupply" : {
        "value" : 30,
        "unit" : "days",
        "system" : "http://unitsofmeasure.org",
        "code" : "d"
      },
      "whenPrepared" : "2025-03-15T10:30:00+08:00",
      "whenHandedOver" : "2025-03-15T11:00:00+08:00",
      "dosageInstruction" : [{
        "sequence" : 1,
        "text" : "Take 1 tablet once daily"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationDispense"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/MedicationStatement/medicationstatement-single-example",
    "resource" : {
      "resourceType" : "MedicationStatement",
      "id" : "medicationstatement-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-medicationstatement"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_medicationstatement-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement medicationstatement-single-example</b></p><a name=\"medicationstatement-single-example\"> </a><a name=\"hcmedicationstatement-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-medicationstatement.html\">PH Core Medication Statement</a></p></div><p><b>status</b>: Active</p><p><b>medication</b>: <span title=\"Codes:{https://verification.fda.gov.ph DRP-10144}\">Twinact 40mg/5mg tablet</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>context</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>effective</b>: 2025-03-10 --&gt; (ongoing)</p><p><b>dateAsserted</b>: 2025-03-15 09:00:00+0800</p><p><b>informationSource</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 38341003}\">Hypertensive disorder</span></p><p><b>note</b>: </p><blockquote><div><p>Patient reports taking medication once daily for hypertension</p>\n</div></blockquote><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Sequence</b></td><td><b>Text</b></td><td><b>Timing</b></td><td><b>Route</b></td></tr><tr><td style=\"display: none\">*</td><td>1</td><td>Take 1 tablet once daily</td><td>Once per 1 day</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration PO}\">Swallow, oral</span></td></tr></table></div>"
      },
      "status" : "active",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "https://verification.fda.gov.ph",
          "code" : "DRP-10144",
          "display" : "Twinact"
        }],
        "text" : "Twinact 40mg/5mg tablet"
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "context" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "effectivePeriod" : {
        "start" : "2025-03-10"
      },
      "dateAsserted" : "2025-03-15T09:00:00+08:00",
      "informationSource" : {
        "reference" : "Patient/patient-single-example"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "38341003",
          "display" : "Hypertensive disorder"
        }]
      }],
      "note" : [{
        "text" : "Patient reports taking medication once daily for hypertension"
      }],
      "dosage" : [{
        "sequence" : 1,
        "text" : "Take 1 tablet once daily",
        "timing" : {
          "repeat" : {
            "frequency" : 1,
            "period" : 1,
            "periodUnit" : "d"
          }
        },
        "route" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration",
            "code" : "PO",
            "display" : "Swallow, oral"
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationStatement"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/MedicationAdministration/medicationadministration-single-example",
    "resource" : {
      "resourceType" : "MedicationAdministration",
      "id" : "medicationadministration-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-medicationadministration"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationAdministration_medicationadministration-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationAdministration medicationadministration-single-example</b></p><a name=\"medicationadministration-single-example\"> </a><a name=\"hcmedicationadministration-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-medicationadministration.html\">PH Core Medication Administration</a></p></div><p><b>status</b>: Completed</p><p><b>medication</b>: <span title=\"Codes:{https://verification.fda.gov.ph DRP-10144}\">Twinact 40mg/5mg tablet</span></p><p><b>subject</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>context</b>: <a href=\"Encounter-encounter-single-example.html\">Encounter: identifier = http://example.org/encounter-id#ENC-12345; status = finished; class = ambulatory (ActCode#AMB); type = ambulatory; period = 2025-03-15 09:00:00+0800 --&gt; 2025-03-15 11:30:00+0800</a></p><p><b>effective</b>: 2025-03-15 11:15:00+0800</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></td></tr></table><p><b>request</b>: <a href=\"Bundle-transaction-example.html#MedicationRequest_medicationrequest-single-example\">MedicationRequest: status = active; intent = order; priority = routine; medication[x] = Twinact 40mg/5mg tablet; authoredOn = 2025-03-15 09:00:00+0800; reasonCode = Hypertensive disorder; note = Continue the prescribed once-daily antihypertensive medication</a></p><h3>Dosages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Text</b></td><td><b>Route</b></td><td><b>Dose</b></td></tr><tr><td style=\"display: none\">*</td><td>1 tablet taken orally</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration PO}\">Swallow, oral</span></td><td>1 tablet<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td></tr></table></div>"
      },
      "status" : "completed",
      "medicationCodeableConcept" : {
        "coding" : [{
          "system" : "https://verification.fda.gov.ph",
          "code" : "DRP-10144",
          "display" : "Twinact"
        }],
        "text" : "Twinact 40mg/5mg tablet"
      },
      "subject" : {
        "reference" : "Patient/patient-single-example"
      },
      "context" : {
        "reference" : "Encounter/encounter-single-example"
      },
      "effectiveDateTime" : "2025-03-15T11:15:00+08:00",
      "performer" : [{
        "actor" : {
          "reference" : "Patient/patient-single-example"
        }
      }],
      "request" : {
        "reference" : "MedicationRequest/medicationrequest-single-example"
      },
      "dosage" : {
        "text" : "1 tablet taken orally",
        "route" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration",
            "code" : "PO",
            "display" : "Swallow, oral"
          }]
        },
        "dose" : {
          "value" : 1,
          "unit" : "tablet",
          "system" : "http://unitsofmeasure.org",
          "code" : "1"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MedicationAdministration"
    }
  }]
}

```
