# Allergy with authorship and transmission - Draft PH Core Implementation Guide v0.2.1

## Example Bundle: Allergy with authorship and transmission



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-allergy-provenance-example",
  "type" : "searchset",
  "timestamp" : "2023-01-17T09:05:00+08:00",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://example.org/fhir/AllergyIntolerance?patient=Patient/patient-single-example&_revinclude=Provenance:target"
  }],
  "entry" : [{
    "fullUrl" : "https://example.org/fhir/AllergyIntolerance/allergy-single-example",
    "resource" : {
      "resourceType" : "AllergyIntolerance",
      "id" : "allergy-single-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-allergyintolerance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AllergyIntolerance_allergy-single-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AllergyIntolerance allergy-single-example</b></p><a name=\"allergy-single-example\"> </a><a name=\"hcallergy-single-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-allergyintolerance.html\">PH Core AllergyIntolerance</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/allergyintolerance-verification confirmed}\">Confirmed</span></p><p><b>criticality</b>: High Risk</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 294494002}\">Benethamine penicillin allergy</span></p><p><b>patient</b>: <a href=\"Patient-patient-single-example.html\">Juan Dela Fuente Dela Cruz  Male, DoB: 1980-01-01 ( http://philhealth.gov.ph/fhir/Identifier/philhealth-id#PhilHealthID#63-584789845-5)</a></p><p><b>onset</b>: 2023-01-15</p><p><b>note</b>: </p><blockquote><div><p>Patient reported rash and swelling after penicillin administration.</p>\n</div></blockquote><h3>Reactions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Manifestation</b></td><td><b>Severity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 271807003}\">Skin rash</span></td><td>Severe</td></tr></table></div>"
      },
      "clinicalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
          "code" : "active",
          "display" : "Active"
        }],
        "text" : "Active"
      },
      "verificationStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
          "code" : "confirmed",
          "display" : "Confirmed"
        }],
        "text" : "Confirmed"
      },
      "criticality" : "high",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "294494002",
          "display" : "Benethamine penicillin allergy"
        }],
        "text" : "Benethamine penicillin allergy"
      },
      "patient" : {
        "reference" : "Patient/patient-single-example"
      },
      "onsetDateTime" : "2023-01-15",
      "note" : [{
        "text" : "Patient reported rash and swelling after penicillin administration."
      }],
      "reaction" : [{
        "manifestation" : [{
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "271807003",
            "display" : "Eruption of skin"
          }],
          "text" : "Skin rash"
        }],
        "severity" : "severe"
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Provenance/provenance-allergy-author-example",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "provenance-allergy-author-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_provenance-allergy-author-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance provenance-allergy-author-example</b></p><a name=\"provenance-allergy-author-example\"> </a><a name=\"hcprovenance-allergy-author-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-provenance.html\">PH Core Provenance</a></p></div><p>Provenance for <a href=\"AllergyIntolerance-allergy-single-example.html\">AllergyIntolerance Benethamine penicillin allergy</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2023-01-16 10:00:00+0800</td></tr><tr><td>Recorded</td><td>2023-01-16 10:00:15+0800</td></tr><tr><td>Activity</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-DataOperation CREATE}\">create</span></td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td><td><b>On Behalf Of</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type author}\">Author</span></td><td><a href=\"Practitioner-practitioner-single-example.html\">Practitioner Maria Clara Santos (official)</a></td><td><a href=\"Organization-organization-pgh-example.html\">Organization Philippine General Hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "AllergyIntolerance/allergy-single-example"
      }],
      "occurredDateTime" : "2023-01-16T10:00:00+08:00",
      "recorded" : "2023-01-16T10:00:15+08:00",
      "activity" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-DataOperation",
          "code" : "CREATE",
          "display" : "create"
        }]
      },
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "author",
            "display" : "Author"
          }]
        },
        "who" : {
          "reference" : "Practitioner/practitioner-single-example"
        },
        "onBehalfOf" : {
          "reference" : "Organization/organization-pgh-example"
        }
      }]
    },
    "search" : {
      "mode" : "include"
    }
  },
  {
    "fullUrl" : "https://example.org/fhir/Provenance/provenance-allergy-transmitter-example",
    "resource" : {
      "resourceType" : "Provenance",
      "id" : "provenance-allergy-transmitter-example",
      "meta" : {
        "profile" : ["https://fhir.doh.gov.ph/phcore/StructureDefinition/ph-core-provenance"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Provenance_provenance-allergy-transmitter-example\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Provenance provenance-allergy-transmitter-example</b></p><a name=\"provenance-allergy-transmitter-example\"> </a><a name=\"hcprovenance-allergy-transmitter-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ph-core-provenance.html\">PH Core Provenance</a></p></div><p>Provenance for <a href=\"AllergyIntolerance-allergy-single-example.html\">AllergyIntolerance Benethamine penicillin allergy</a></p><p>Summary</p><table class=\"grid\"><tr><td>Occurrence</td><td>2023-01-17 09:00:00+0800</td></tr><tr><td>Recorded</td><td>2023-01-17 09:00:10+0800</td></tr></table><p><b>Agents</b></p><table class=\"grid\"><tr><td><b>Type</b></td><td><b>who</b></td></tr><tr><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/provenance-participant-type transmitter}\">Transmitter</span></td><td><a href=\"Organization-organization-pgh-example.html\">Organization Philippine General Hospital</a></td></tr></table></div>"
      },
      "target" : [{
        "reference" : "AllergyIntolerance/allergy-single-example"
      }],
      "occurredDateTime" : "2023-01-17T09:00:00+08:00",
      "recorded" : "2023-01-17T09:00:10+08:00",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
            "code" : "transmitter",
            "display" : "Transmitter"
          }]
        },
        "who" : {
          "reference" : "Organization/organization-pgh-example"
        }
      }]
    },
    "search" : {
      "mode" : "include"
    }
  }]
}

```
