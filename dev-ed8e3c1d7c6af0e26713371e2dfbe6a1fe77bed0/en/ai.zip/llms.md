# fhir.ph.core#0.2.1: Draft PH Core Implementation Guide(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [PH Core Server](ActorDefinition-PHCoreServer.md)
* [PH Core Server](ActorDefinition-PHCoreServer.ai.md)
* [Sex and Gender Guidance](sex-and-gender-guidance.md)
* [PH Core Client - JSON Representation](ActorDefinition-PHCoreClient.json.md)
* [PH Core Client - TTL Representation](ActorDefinition-PHCoreClient.ttl.md)
* [PH Core Client - XML Representation](ActorDefinition-PHCoreClient.xml.md)
* [Sample Case](sample-case.md)
* [Terminology](terminology.md)
* [PH Core Client](ActorDefinition-PHCoreClient.ai.md)
* [PH Core Server](ActorDefinition-PHCoreServer-testing.md)
* [Artifacts Summary](artifacts.md)
* [PH Core Server - XML Representation](ActorDefinition-PHCoreServer.xml.md)
* [PH Core Client](ActorDefinition-PHCoreClient-testing.md)
* [PH Core Server - JSON Representation](ActorDefinition-PHCoreServer.json.md)
* [](ActorDefinition-PHCoreClient.change.history.md)
* [Client Server Conformance](client-server-conformance.md)
* [Fhir Rest Tutorial](fhir-rest-tutorial.md)
* [PH Core Client](ActorDefinition-PHCoreClient.md)
* [Other Ids](otherIds.md)
* [PH Core Server - TTL Representation](ActorDefinition-PHCoreServer.ttl.md)
* [](ActorDefinition-PHCoreServer.change.history.md)

## Resources

### CodeSystems

* [PH FDA Certificate of Product Registration (CPR) CodeSystem](CodeSystem-PHFDACPRCS.md)
* [PSCED](CodeSystem-PSCED.md)
* [PSGC](CodeSystem-PSGC.md)
* [PSOC](CodeSystem-PSOC.md)
* [Indigenous Groups CodeSystem](CodeSystem-indigenous-status-cs.md)
* [PH Core Disability Type Code System](CodeSystem-ph-core-disability-type-cs.md)
* [PRC CodeSystem](CodeSystem-prc.md)

### ValueSets

* [Barangays](ValueSet-barangays.md)
* [Cities](ValueSet-cities.md)
* [Drugs](ValueSet-drugs-vs.md)
* [Educational Attainments](ValueSet-educational-attainments.md)
* [Indigenous Groups ValueSet](ValueSet-indigenous-status-vs.md)
* [Occupation Classifications](ValueSet-occupational-classifications.md)
* [PH Core Disability Type Value Set](ValueSet-ph-core-disability-type-vs.md)
* [PRC All Codes ValueSet](ValueSet-prc-all-codes.md)
* [PRC Council Codes ValueSet](ValueSet-prc-council-codes.md)
* [PRC Licensure Examinations ValueSet](ValueSet-prc-licensure-examinations.md)
* [PRC Profession Codes ValueSet](ValueSet-prc-profession-codes.md)
* [Provinces](ValueSet-provinces.md)
* [Regions](ValueSet-regions.md)

### Complex-type Profiles

* [PH Core Address](StructureDefinition-ph-core-address.md)

### Resource Profiles

* [PH Core AllergyIntolerance](StructureDefinition-ph-core-allergyintolerance.md)
* [PH Core Claim](StructureDefinition-ph-core-claim.md)
* [PH Core Condition](StructureDefinition-ph-core-condition.md)
* [PH Core Encounter](StructureDefinition-ph-core-encounter.md)
* [PH Core HealthcareService](StructureDefinition-ph-core-healthcareservice.md)
* [PH Core Immunization](StructureDefinition-ph-core-immunization.md)
* [PH Core Location](StructureDefinition-ph-core-location.md)
* [PH Core Medication](StructureDefinition-ph-core-medication.md)
* [PH Core Medication Administration](StructureDefinition-ph-core-medicationadministration.md)
* [PH Core Medication Dispense](StructureDefinition-ph-core-medicationdispense.md)
* [PH Core Medication Request](StructureDefinition-ph-core-medicationrequest.md)
* [PH Core Medication Statement](StructureDefinition-ph-core-medicationstatement.md)
* [PH Core Observation Clinical Result](StructureDefinition-ph-core-observation-clinical-result.md)
* [PH Core Observation](StructureDefinition-ph-core-observation.md)
* [PH Core Organization](StructureDefinition-ph-core-organization.md)
* [PH Core Patient](StructureDefinition-ph-core-patient.md)
* [PH Core Practitioner](StructureDefinition-ph-core-practitioner.md)
* [PH Core PractitionerRole](StructureDefinition-ph-core-practitionerrole.md)
* [PH Core Procedure](StructureDefinition-ph-core-procedure.md)
* [PH Core Provenance](StructureDefinition-ph-core-provenance.md)
* [PH Core RelatedPerson](StructureDefinition-ph-core-relatedperson.md)
* [PH Core ServiceRequest](StructureDefinition-ph-core-serviceRequest.md)
* [PH Core Task](StructureDefinition-ph-core-task.md)

### Extensions

* [Administered Product](StructureDefinition-administered-product.md)
* [Barangay](StructureDefinition-barangay.md)
* [Batch Number](StructureDefinition-batch-number.md)
* [City/Municipality](StructureDefinition-city-municipality.md)
* [Educational Attainment](StructureDefinition-educational-attainment.md)
* [Indigenous status](StructureDefinition-indigenous-status.md)
* [Occupation](StructureDefinition-occupation.md)
* [PH Core PWD Disability Registration](StructureDefinition-ph-core-pwd-disability.md)
* [Province](StructureDefinition-province.md)
* [Race](StructureDefinition-race.md)
* [Region](StructureDefinition-region.md)

### Basics

* [PHCoreClient](Basic-PHCoreClient.md)
* [PHCoreServer](Basic-PHCoreServer.md)

### CapabilityStatements

* [PHCoreClientCapabilityStatement](CapabilityStatement-PHCoreClientCapabilityStatement.md)
* [PHCoreServerCapabilityStatement](CapabilityStatement-PHCoreServerCapabilityStatement.md)

### ImplementationGuides

* [Draft PH Core Implementation Guide](ImplementationGuide-fhir.ph.core.md)

### NamingSystems

* [PhilHealthID](NamingSystem-PhilHealthIDNS.md)
* [PhilSysID](NamingSystem-PhilSysIDNS.md)

### SearchParameters

* [PHCorePractitionerIdentifier](SearchParameter-practitioner-identifier.md)

### Examples

* [allergy-single-example (AllergyIntolerance)](AllergyIntolerance-allergy-single-example.md)
* [bundle-acs-case-example (Bundle)](Bundle-bundle-acs-case-example.md)
* [bundle-allergy-provenance-example (Bundle)](Bundle-bundle-allergy-provenance-example.md)
* [bundle-observation-provenance-example (Bundle)](Bundle-bundle-observation-provenance-example.md)
* [transaction-example (Bundle)](Bundle-transaction-example.md)
* [claim-single-example (Claim)](Claim-claim-single-example.md)
* [condition-appendicitis-example (Condition)](Condition-condition-appendicitis-example.md)
* [condition-single-example (Condition)](Condition-condition-single-example.md)
* [philhealth-coverage-example (Coverage)](Coverage-philhealth-coverage-example.md)
* [encounter-immunization-example (Encounter)](Encounter-encounter-immunization-example.md)
* [encounter-single-example (Encounter)](Encounter-encounter-single-example.md)
* [encounter-surgery-example (Encounter)](Encounter-encounter-surgery-example.md)
* [Outpatient Department - General Medicine (HealthcareService)](HealthcareService-healthcareservice-single-example.md)
* [immunization-single-example (Immunization)](Immunization-immunization-single-example.md)
* [Philippine General Hospital (Location)](Location-location-single-example.md)
* [medication-single-example (Medication)](Medication-medication-single-example.md)
* [medication-vaccine-example (Medication)](Medication-medication-vaccine-example.md)
* [observation-bp-example (Observation)](Observation-observation-bp-example.md)
* [observation-component-unavailable (Observation)](Observation-observation-component-unavailable.md)
* [observation-derived-bmi-example (Observation)](Observation-observation-derived-bmi-example.md)
* [observation-environmental-temp-example (Observation)](Observation-observation-environmental-temp-example.md)
* [observation-glucose-example (Observation)](Observation-observation-glucose-example.md)
* [observation-height-example (Observation)](Observation-observation-height-example.md)
* [observation-lab-panel-example (Observation)](Observation-observation-lab-panel-example.md)
* [observation-part-of-procedure-example (Observation)](Observation-observation-part-of-procedure-example.md)
* [observation-performer-role-example (Observation)](Observation-observation-performer-role-example.md)
* [observation-potassium-example (Observation)](Observation-observation-potassium-example.md)
* [observation-result-unavailable (Observation)](Observation-observation-result-unavailable.md)
* [observation-sodium-example (Observation)](Observation-observation-sodium-example.md)
* [observation-vitals-encounter-example (Observation)](Observation-observation-vitals-encounter-example.md)
* [observation-weight-example (Observation)](Observation-observation-weight-example.md)
* [Philippine General Hospital (Organization)](Organization-organization-pgh-example.md)
* [Philippine Health Insurance Corporation (illustrative) (Organization)](Organization-organization-philhealth-example.md)
* [Professional Regulation Commission (illustrative) (Organization)](Organization-organization-prc-example.md)
* [Example Manila Health Center (Organization)](Organization-organization-single-example.md)
* [patient-anonymous-mothers-maiden-name-example (Patient)](Patient-patient-anonymous-mothers-maiden-name-example.md)
* [patient-explicit-absence-example (Patient)](Patient-patient-explicit-absence-example.md)
* [patient-sex-and-gender-example (Patient)](Patient-patient-sex-and-gender-example.md)
* [patient-single-example (Patient)](Patient-patient-single-example.md)
* [practitioner-single-example (Practitioner)](Practitioner-practitioner-single-example.md)
* [practitionerrole-single-example (PractitionerRole)](PractitionerRole-practitionerrole-single-example.md)
* [procedure-single-example (Procedure)](Procedure-procedure-single-example.md)
* [procedure-unknown-date-example (Procedure)](Procedure-procedure-unknown-date-example.md)
* [relatedperson-single-example (RelatedPerson)](RelatedPerson-relatedperson-single-example.md)
* [servicerequest-appendectomy-example (ServiceRequest)](ServiceRequest-servicerequest-appendectomy-example.md)
* [servicerequest-single-example (ServiceRequest)](ServiceRequest-servicerequest-single-example.md)
